import json
from pathlib import Path
import random
import sys
import time
import numpy as np
import os, glob
from torch.utils import data
import os
import time
import random
import pickle
import numpy as np
from tqdm import tqdm
from importlib import import_module
from scipy.ndimage import zoom
import yaml
import torch

NORMALIZATION_STATS = {
    'azimuth_fov': {'min': 90.0, 'max': 180.0},
    'max_range': {'min': 14.24, 'max': 118.0},
    'max_velocity': {'min': 0.0, 'max': 23.02},
    'range_resolution': {'min': 0.047, 'max': 0.97},
    'velocity_resolution': {'min': 0.0, 'max': 0.48},
    'angular_resolution': {'min': 0.352, 'max': 1.0}
}
NUMERICAL_KEYS_FOR_FILM = list(NORMALIZATION_STATS.keys())

def normalize_condition_vector_for_film(vector, ordered_keys):
    """为FiLM的条件向量进行标准的 [0, 1] Min-Max 归一化。"""
    vector = np.array(vector, dtype=np.float32)
    for i, key in enumerate(ordered_keys):
        if key in NUMERICAL_KEYS_FOR_FILM:
            stats = NORMALIZATION_STATS[key]
            min_val, max_val = stats['min'], stats['max']
            if max_val > min_val:
                vector[i] = (vector[i] - min_val) / (max_val - min_val)
            else:
                vector[i] = 0.0
    return vector

def Create_CRUW_Finetune_Dataset(dataset, config_dict, sensor_config_path=None, data_dir = '/media/ljm/Raid/ChenHongliang/RAGM/models/CRUW_finetune/data'):
    sensor_params = None
    if sensor_config_path and os.path.exists(sensor_config_path):
        with open(sensor_config_path, 'r') as f:
            sensor_configs = json.load(f)
            sensor_params = sensor_configs.get("CRUW", {})

    train_dataset = CRDataset(data_dir=data_dir, dataset=dataset, config_dict=config_dict, split='train', is_train=True, sensor_params=sensor_params)

    return train_dataset

class SensorConfig:
    """ SensorConfig class that specifies the dataset sensor setups. """

    def __init__(self,
                 dataset: str,
                 camera_cfg: dict,
                 radar_cfg: dict,
                 calib_cfg: dict):
        self.dataset = dataset
        self.camera_cfg = camera_cfg
        self.radar_cfg = radar_cfg
        self.calib_cfg = calib_cfg

    def serialize(self) -> dict:
        return {
            "dataset": self.dataset,
            "camera_cfg": self.camera_cfg,
            "radar_cfg": self.radar_cfg,
            "calib_cfg": self.calib_cfg
        }

    @classmethod
    def initialize(cls, content: dict):
        return cls(
            content["dataset"],
            content["camera_cfg"],
            content["radar_cfg"],
            content["calib_cfg"]
        )

    def load_cam_calib(self, calib_yaml_l, calib_yaml_r=None):
        with open(calib_yaml_l, "r") as stream:
            data = yaml.safe_load(stream)
            K, D, R, P = parse_cam_matrices(data)
            self.calib_cfg['cam_0'] = {}
            self.calib_cfg['cam_0']['camera_matrix'] = K
            self.calib_cfg['cam_0']['distortion_coefficients'] = D
            self.calib_cfg['cam_0']['rectification_matrix'] = R
            self.calib_cfg['cam_0']['projection_matrix'] = P
        if calib_yaml_r is not None:
            with open(calib_yaml_r, "r") as stream:
                data = yaml.safe_load(stream)
                K, D, R, P = parse_cam_matrices(data)
                self.calib_cfg['cam_1'] = {}
                self.calib_cfg['cam_1']['camera_matrix'] = K
                self.calib_cfg['cam_1']['distortion_coefficients'] = D
                self.calib_cfg['cam_1']['rectification_matrix'] = R
                self.calib_cfg['cam_1']['projection_matrix'] = P

    def load_cam_calibs(self, data_root, calib_yaml_paths):
        self.calib_cfg['cam_calib'] = {}
        self.calib_cfg['cam_calib']['load_success'] = True
        for date in calib_yaml_paths.keys():
            self.calib_cfg['cam_calib'][date] = {}
            n_paths = len(calib_yaml_paths[date])
            calib_yaml_path = os.path.join(data_root, calib_yaml_paths[date][0])
            if os.path.exists(calib_yaml_path):
                with open(calib_yaml_path, "r") as stream:
                    data = yaml.safe_load(stream)
                    K, D, R, P = parse_cam_matrices(data)
                    self.calib_cfg['cam_calib'][date]['cam_0'] = {}
                    self.calib_cfg['cam_calib'][date]['cam_0']['camera_matrix'] = K
                    self.calib_cfg['cam_calib'][date]['cam_0']['distortion_coefficients'] = D
                    self.calib_cfg['cam_calib'][date]['cam_0']['rectification_matrix'] = R
                    self.calib_cfg['cam_calib'][date]['cam_0']['projection_matrix'] = P
            else:
                self.calib_cfg['cam_calib']['load_success'] = False
            if n_paths == 2:
                calib_yaml_path = os.path.join(data_root, calib_yaml_paths[date][1])
                if os.path.exists(calib_yaml_path):
                    with open(calib_yaml_path, "r") as stream:
                        data = yaml.safe_load(stream)
                        K, D, R, P = parse_cam_matrices(data)
                        self.calib_cfg['cam_calib'][date]['cam_1'] = {}
                        self.calib_cfg['cam_calib'][date]['cam_1']['camera_matrix'] = K
                        self.calib_cfg['cam_calib'][date]['cam_1']['distortion_coefficients'] = D
                        self.calib_cfg['cam_calib'][date]['cam_1']['rectification_matrix'] = R
                        self.calib_cfg['cam_calib'][date]['cam_1']['projection_matrix'] = P
                else:
                    self.calib_cfg['cam_calib']['load_success'] = False


class ObjectConfig:
    """ ObjectConfig class that specifies the object configurations in the dataset. """

    def __init__(self,
                 n_class: int,
                 classes: list,
                 sizes: dict):
        self.n_class = n_class
        self.classes = classes
        self.sizes = sizes

    def serialize(self) -> dict:
        return {
            "n_classes": self.n_class,
            "classes": self.classes,
            "sizes": self.sizes
        }

    @classmethod
    def initialize(cls, content: dict):
        return cls(
            content["n_classes"],
            content["classes"],
            content["sizes"]
        )

class CRUW:
    """ Dataset class for CRUW. """

    def __init__(self,
                 data_root: str,
                 sensor_config_name: str = '/media/ljm/Raid/ChenHongliang/RAGM/models/CRUW_finetune/cruw/dataset_configs/sensor_config_rod2021.json',
                 object_config_name: str = '/media/ljm/Raid/ChenHongliang/RAGM/models/CRUW_finetune/cruw/dataset_configs/object_config.json'):
        self.data_root = data_root
        self.sensor_cfg = self._load_sensor_config(sensor_config_name)
        self.dataset = self.sensor_cfg.dataset
        self.object_cfg = self._load_object_config(object_config_name)

        self.range_grid = confmap2ra(self.sensor_cfg.radar_cfg, name='range')
        self.angle_grid = confmap2ra(self.sensor_cfg.radar_cfg, name='angle')
        self.range_grid_label = labelmap2ra(self.sensor_cfg.radar_cfg, name='range')
        self.angle_grid_label = labelmap2ra(self.sensor_cfg.radar_cfg, name='angle')

    def __str__(self):
        print_log = '<CRUW Dataset Object>\n'
        print_log += "Dataset name:   %s\n" % self.dataset
        cam_flag = True if self.sensor_cfg.camera_cfg else False
        rad_flag = True if self.sensor_cfg.radar_cfg else False
        print_log += "Sensor configs: camera = %s | radar = %s\n" % (str(cam_flag).ljust(5), str(rad_flag).ljust(5))
        cam_calib_flag = True if self.sensor_cfg.calib_cfg['cam_calib_paths'] else False
        print_log += "Calibration:    camera = %s | cross = %s\n" % (str(cam_calib_flag).ljust(5), str(True).ljust(5))
        print_log += "Object configs: n_class = %d\n" % self.object_cfg.n_class
        mapping_flag = True if len(self.angle_grid) != 0 and len(self.range_grid) != 0 else False
        print_log += "Coor mappings:  %s\n" % mapping_flag
        return print_log

    def _load_sensor_config(self, config_name) -> SensorConfig:
        """
        Create a SensorConfig class for CRUW dataset.
        The config file is located in 'cruw/dataset_configs' folder.
        :param config_name: Name of configuration
        :return: SensorConfig
        """
        # check if config exists
        cfg_path = config_name
        assert os.path.exists(cfg_path), 'Configuration {} not found'.format(config_name)

        # load config file to Loc3DCamConfig
        with open(cfg_path, 'r') as f:
            data = json.load(f)
        cfg = SensorConfig.initialize(data)
        # cam_0_calib_yaml = os.path.join(self.data_root, 'calib', cfg.calib_cfg['cam_calib_name'], 'left.yaml')
        # cam_1_calib_yaml = os.path.join(self.data_root, 'calib', cfg.calib_cfg['cam_calib_name'], 'right.yaml')
        # cfg.load_cam_calib(cam_0_calib_yaml, cam_1_calib_yaml)
        cfg.load_cam_calibs(self.data_root, cfg.calib_cfg['cam_calib_paths'])
        if not cfg.calib_cfg['cam_calib']['load_success']:
            print('warning: loading calibration data failed')

        return cfg

    def _load_object_config(self, config_name) -> ObjectConfig:
        """
        Create a ObjectConfig class for CRUW dataset.
        The config file is located in 'cruw/dataset_configs' folder.
        :param config_name: Name of configuration
        :return: ObjectConfig
        """
        # check if config exists
        cfg_path = config_name
        assert os.path.exists(cfg_path), 'Configuration {} not found'.format(config_name)

        # load config file to Loc3DCamConfig
        with open(cfg_path, 'r') as f:
            data = json.load(f)
        cfg = ObjectConfig.initialize(data)

        return cfg

class CRDataset(data.Dataset):
    """
    Pytorch Dataloader for CR Dataset
    :param detail_dir: data details directory
    :param confmap_dir: confidence maps directory
    :param win_size: seqence window size
    :param n_class: number of classes for detection
    :param step: frame step inside each sequence
    :param stride: data sampling
    :param set_type: train, valid, test
    :param is_random_chirp: random load chirp or not
    """

    def __init__(self, data_dir, dataset, config_dict, split, is_random_chirp=True, subset=None, is_train=False, noise_channel=False, sensor_params=None):
        # parameters settings
        self.ordered_keys = [
            'sensor_awr', 'sensor_retina', 'platform_mobile', 'platform_static', 'platform_mixed',
            'azimuth_fov', 'max_range', 'max_velocity', 'range_resolution',
            'velocity_resolution', 'angular_resolution', 'has_velocity'
        ]
        self.raw_params = sensor_params
        # 从原始参数创建向量
        condition_vector_list  = [self.raw_params[key] for key in self.ordered_keys]
        
        # 应用标准 [0, 1] 归一化
        normalized_vector = normalize_condition_vector_for_film(condition_vector_list, self.ordered_keys)

        # 存储最终的FiLM条件张量
        self.condition_tensor = torch.tensor(normalized_vector, dtype=torch.float32)

        self.mean_log = 0.001544
        self.std_log = 0.017349
        self.data_dir = data_dir
        self.is_train = is_train
        self.dataset = dataset
        self.config_dict = config_dict
        self.n_class = dataset.object_cfg.n_class
        self.win_size = config_dict['train_cfg']['win_size']
        self.split = split
        if split == 'train' or split == 'valid':
            self.step = config_dict['train_cfg']['train_step']
            self.stride = config_dict['train_cfg']['train_stride']
        else:
            self.step = config_dict['test_cfg']['test_step']
            self.stride = config_dict['test_cfg']['test_stride']
        self.is_random_chirp = is_random_chirp
        self.n_chirps = 1
        self.noise_channel = noise_channel

        # Dataloader for MNet
        if 'mnet_cfg' in self.config_dict['model_cfg']:
            in_chirps, out_channels = self.config_dict['model_cfg']['mnet_cfg']
            self.n_chirps = in_chirps
        self.chirp_ids = self.dataset.sensor_cfg.radar_cfg['chirp_ids']

        # dataset initialization
        self.image_paths = []
        self.radar_paths = []
        self.obj_infos = []
        self.confmaps = []
        self.n_data = 0
        self.index_mapping = []

        if subset is not None:
            self.data_files = [subset + '.pkl']
        else:
            # self.data_files = list_pkl_filenames(config_dict['dataset_cfg'], split)
            self.data_files = list_pkl_filenames_from_prepared(data_dir, split)
        self.seq_names = [name.split('.')[0] for name in self.data_files]
        self.n_seq = len(self.seq_names)

        split_folder = split
        for seq_id, data_file in enumerate(tqdm(self.data_files)):
            data_file_path = os.path.join(data_dir, split_folder, data_file)
            data_details = pickle.load(open(data_file_path, 'rb'))
            if split == 'train' or split == 'valid':
                assert data_details['anno'] is not None
            n_frame = data_details['n_frame']
            self.image_paths.append(data_details['image_paths'])
            self.radar_paths.append(data_details['radar_paths'])
            n_data_in_seq = (n_frame - (self.win_size * self.step - 1)) // self.stride + (
                1 if (n_frame - (self.win_size * self.step - 1)) % self.stride > 0 else 0)
            self.n_data += n_data_in_seq
            for data_id in range(n_data_in_seq):
                self.index_mapping.append([seq_id, data_id * self.stride])
            if data_details['anno'] is not None:
                self.obj_infos.append(data_details['anno']['metadata'])
                self.confmaps.append(data_details['anno']['confmaps'])

    def __len__(self):
        """Total number of data/label pairs"""
        return self.n_data

    def __getitem__(self, index):

        seq_id, data_id = self.index_mapping[index]
        seq_name = self.seq_names[seq_id]
        image_paths = self.image_paths[seq_id]
        radar_paths = self.radar_paths[seq_id]
        if len(self.confmaps) != 0:
            this_seq_obj_info = self.obj_infos[seq_id]
            this_seq_confmap = self.confmaps[seq_id]

        data_dict = dict(
            status=True,
            seq_names=seq_name,
            image_paths=[]
        )

        if self.is_random_chirp:
            chirp_id = random.randint(0, len(self.chirp_ids) - 1)
        else:
            chirp_id = 0

        # Dataloader for MNet
        if 'mnet_cfg' in self.config_dict['model_cfg']:
            chirp_id = self.chirp_ids

        radar_configs = self.dataset.sensor_cfg.radar_cfg
        ramap_rsize = radar_configs['ramap_rsize']
        ramap_asize = radar_configs['ramap_asize']

        # Load radar data
        try:
            if radar_configs['data_type'] == 'ROD2021':
                if isinstance(chirp_id, int):
                    radar_npy_win = np.zeros((self.win_size, ramap_rsize, ramap_asize, 2), dtype=np.float32)
                    for idx, frameid in enumerate(
                            range(data_id, data_id + self.win_size * self.step, self.step)):
                        radar_npy_win[idx, :, :, :] = np.load(radar_paths[frameid][chirp_id])
                        data_dict['image_paths'].append(image_paths[frameid])
                elif isinstance(chirp_id, list):
                    radar_npy_win = np.zeros((self.win_size, self.n_chirps, ramap_rsize, ramap_asize, 2),dtype=np.float32)
                    for idx, frameid in enumerate(range(data_id, data_id + self.win_size * self.step, self.step)):
                        for cid, c in enumerate(chirp_id):
                            npy_path = radar_paths[frameid][cid]
                            radar_npy_win[idx, cid, :, :, :] = np.load(npy_path)
                        data_dict['image_paths'].append(image_paths[frameid])
                else:
                    raise TypeError
            else:
                raise NotImplementedError

            data_dict['start_frame'] = data_id
            data_dict['end_frame'] = data_id + self.win_size * self.step - 1

        except:
            # in case load npy fail
            data_dict['status'] = False
            if not os.path.exists('./tmp'):
                os.makedirs('./tmp')
            log_name = 'loadnpyfail-' + time.strftime("%Y%m%d-%H%M%S") + '.txt'
            with open(os.path.join('./tmp', log_name), 'w') as f_log:
                f_log.write('npy path: ' + radar_paths[frameid][chirp_id] + \
                            '\nframe indices: %d:%d:%d' % (data_id, data_id + self.win_size * self.step, self.step))
            return data_dict

        # Dataloader for MNet
        if 'mnet_cfg' in self.config_dict['model_cfg']:
            radar_npy_win = np.transpose(radar_npy_win, (4, 0, 1, 2, 3))
            assert radar_npy_win.shape == (
                2, self.win_size, self.n_chirps, radar_configs['ramap_rsize'], radar_configs['ramap_asize'])
        else:
            radar_npy_win = np.transpose(radar_npy_win, (3, 0, 1, 2))
            assert radar_npy_win.shape == (2, self.win_size, radar_configs['ramap_rsize'], radar_configs['ramap_asize'])

        power_data = radar_npy_win[0, ...]**2 + radar_npy_win[1, ...]**2
        power_data = preprocess_data(power_data)
        combined_ra_maps = power_data.reshape(self.win_size * self.n_chirps,
                                          radar_configs['ramap_rsize'],
                                          radar_configs['ramap_asize'])
        target_h_ra = 256
        target_w_ra = 256
        zoom_factor_h = target_h_ra / radar_configs['ramap_rsize']
        zoom_factor_w = target_w_ra / radar_configs['ramap_asize']
        upsampled_maps_list = []
        for i in range(combined_ra_maps.shape[0]):
            ra_map = combined_ra_maps[i, :, :]
            upsampled_ra_map = zoom(ra_map, (zoom_factor_h, zoom_factor_w), order=1) # Bilinear
            upsampled_maps_list.append(upsampled_ra_map)

        final_data_content = np.stack(upsampled_maps_list, axis=0)
        
        RAD_data = (final_data_content - self.mean_log) / self.std_log
        RAD_data = normalize_data(RAD_data)
        RAD_data = np.transpose(RAD_data, (1, 2, 0))

        # Load annotations
        if len(self.confmaps) != 0:
            confmap_gt = this_seq_confmap[data_id:data_id + self.win_size * self.step:self.step]
            confmap_gt = np.transpose(confmap_gt, (1, 0, 2, 3))
            obj_info = this_seq_obj_info[data_id:data_id + self.win_size * self.step:self.step]
            if self.noise_channel:
                assert confmap_gt.shape == \
                       (self.n_class + 1, self.win_size, radar_configs['ramap_rsize'], radar_configs['ramap_asize'])
            else:
                confmap_gt = confmap_gt[:self.n_class]
                assert confmap_gt.shape == \
                       (self.n_class, self.win_size, radar_configs['ramap_rsize'], radar_configs['ramap_asize'])

            data_dict['anno'] = dict(
                obj_infos=obj_info,
                confmaps=confmap_gt,
            )
        else:
            data_dict['anno'] = None
        return {
            'data': torch.tensor(RAD_data, dtype=torch.float32),
            'label': torch.tensor(confmap_gt, dtype=torch.float32),
            'seq_names':data_dict['seq_names'],
            'radar_npy_win': radar_npy_win,
            'image_paths': data_dict['image_paths'],
            'condition': self.condition_tensor, # The normalized tensor for the model
            'raw_params': self.raw_params       # The original dict for visualization & pos encoding
        }

def normalize_data(data_input): # 变量名修改以避免与torch.data冲突
    data_min = data_input.min()
    data_max = data_input.max()
    if (data_max - data_min) < 1e-6: 
        normalized_data = np.zeros_like(data_input) if data_max == 0 else data_input / (data_max + 1e-6) 
    else:
        normalized_data = (data_input - data_min) / (data_max - data_min) * 2.0 - 1.0
    return normalized_data

def preprocess_data(power_data_input): 
    """
    对输入的功率数据进行预处理，这里主要是对数变换。
    power_data_input: 已经是计算好的功率值 (例如 real^2 + imag^2)
    """
    # 移除了 getMagnitude 调用，因为输入已经是功率
    log_power_data = getLog(power_data_input)
    return log_power_data

def getLog(target_array, scalar=1., log_10=True):
    if log_10:
        return scalar * np.log10(target_array + 1.)
    else: 
        return scalar * np.log(target_array + 1.)

def load_configs_from_file(config_path):
    module_name = os.path.basename(config_path)[:-3]
    if '.' in module_name:
        raise ValueError('Dots are not allowed in config file path.')
    config_dir = os.path.dirname(config_path)
    sys.path.insert(0, config_dir)
    mod = import_module(module_name)
    sys.path.pop(0)
    cfg_dict = {
        name: value
        for name, value in mod.__dict__.items()
        if not name.startswith('__')
    }
    return cfg_dict

def update_config_dict(config_dict, args):
    # dataset_cfg
    if hasattr(args, 'data_root') and args.data_root is not None:
        data_root_old = config_dict['dataset_cfg']['base_root']
        config_dict['dataset_cfg']['base_root'] = args.data_root
        config_dict['dataset_cfg']['data_root'] = config_dict['dataset_cfg']['data_root'].replace(data_root_old,
                                                                                                  args.data_root)
        config_dict['dataset_cfg']['anno_root'] = config_dict['dataset_cfg']['anno_root'].replace(data_root_old,
                                                                                                  args.data_root)

    # model_cfg
    if hasattr(args, 'model_type') and args.model_type is not None:
        config_dict['model_cfg']['type'] = args.model_type
    if hasattr(args, 'model_name') and args.model_name is not None:
        config_dict['model_cfg']['name'] = args.model_name
    if hasattr(args, 'max_dets') and args.max_dets is not None:
        config_dict['model_cfg']['max_dets'] = args.max_dets
    if hasattr(args, 'peak_thres') and args.peak_thres is not None:
        config_dict['model_cfg']['peak_thres'] = args.peak_thres
    if hasattr(args, 'ols_thres') and args.ols_thres is not None:
        config_dict['model_cfg']['ols_thres'] = args.ols_thres
    if hasattr(args, 'stacked_num') and args.stacked_num is not None:
        config_dict['model_cfg']['stacked_num'] = args.stacked_num
    if hasattr(args, 'mnet_cfg') and args.mnet_cfg is not None:
        config_dict['model_cfg']['mnet_cfg'] = args.mnet_cfg
    if hasattr(args, 'dcn') and args.dcn is not None:
        config_dict['model_cfg']['dcn'] = args.dcn

    # train_cfg
    if hasattr(args, 'n_epoch') and args.n_epoch is not None:
        config_dict['train_cfg']['n_epoch'] = args.n_epoch
    if hasattr(args, 'batch_size') and args.batch_size is not None:
        config_dict['train_cfg']['batch_size'] = args.batch_size
    if hasattr(args, 'lr') and args.lr is not None:
        config_dict['train_cfg']['lr'] = args.lr
    if hasattr(args, 'lr_step') and args.lr_step is not None:
        config_dict['train_cfg']['lr_step'] = args.lr_step
    if hasattr(args, 'win_size') and args.win_size is not None:
        config_dict['train_cfg']['win_size'] = args.win_size
    if hasattr(args, 'train_step') and args.train_step is not None:
        config_dict['train_cfg']['train_step'] = args.train_step
    if hasattr(args, 'train_stride') and args.train_stride is not None:
        config_dict['train_cfg']['train_stride'] = args.train_stride
    if hasattr(args, 'log_step') and args.log_step is not None:
        config_dict['train_cfg']['log_step'] = args.log_step
    if hasattr(args, 'save_step') and args.save_step is not None:
        config_dict['train_cfg']['save_step'] = args.save_step

    # test_cfg
    if hasattr(args, 'test_step') and args.test_step is not None:
        config_dict['test_cfg']['test_step'] = args.test_step
    if hasattr(args, 'test_stride') and args.test_stride is not None:
        config_dict['test_cfg']['test_stride'] = args.test_stridea
    if hasattr(args, 'rr_min') and args.rr_min is not None:
        config_dict['test_cfg']['rr_min'] = args.rr_min
    if hasattr(args, 'rr_max') and args.rr_max is not None:
        config_dict['test_cfg']['rr_max'] = args.rr_max
    if hasattr(args, 'ra_min') and args.ra_min is not None:
        config_dict['test_cfg']['ra_min'] = args.ra_min
    if hasattr(args, 'ra_max') and args.ra_max is not None:
        config_dict['test_cfg']['ra_max'] = args.ra_max

    return config_dict

def list_pkl_filenames(dataset_configs, split):
    data_root = dataset_configs['data_root']
    seqs = dataset_configs[split]['seqs']
    seqs_pkl_names = [name + '.pkl' for name in seqs]
    return seqs_pkl_names


def list_pkl_filenames_from_prepared(data_dir, split):
    seqs_pkl_names = sorted(os.listdir(os.path.join(data_dir, split)))
    return seqs_pkl_names

import numpy as np
import math
import scipy.constants

def parse_cam_matrices(data):
    camera_matrix = data['camera_matrix']
    distortion_coefficients = data['distortion_coefficients']
    rectification_matrix = data['rectification_matrix']
    projection_matrix = data['projection_matrix']

    K = np.array(camera_matrix['data'])
    K = np.reshape(K, (camera_matrix['rows'], camera_matrix['cols']))
    D = np.array(distortion_coefficients['data'])
    D = np.reshape(D, (distortion_coefficients['rows'], distortion_coefficients['cols']))
    D = np.squeeze(D)
    R = np.array(rectification_matrix['data'])
    R = np.reshape(R, (rectification_matrix['rows'], rectification_matrix['cols']))
    P = np.array(projection_matrix['data'])
    P = np.reshape(P, (projection_matrix['rows'], projection_matrix['cols']))

    return K, D, R, P




class HumanAnnoConfig:
    def __init__(self,
                 gt_root: str,
                 gt_dir_name: str,
                 gt_format: str,
                 seq_names: list,
                 dataset: str,
                 date_included: bool,
                 output_dir: str):
        self.gt_root = gt_root
        self.gt_dir_name = gt_dir_name
        self.gt_format = gt_format
        self.seq_names = seq_names
        self.dataset = dataset
        self.date_included = date_included
        self.output_dir = output_dir

    def serialize(self) -> dict:
        return {
            "gt_root": self.gt_root,
            "gt_dir_name": self.gt_dir_name,
            "gt_format": self.gt_format,
            "seq_names": self.seq_names,
            "dataset": self.dataset,
            "date_included": self.date_included,
            "output_dir": self.output_dir
        }

    @classmethod
    def initialize(cls, content: dict):
        return cls(
            content['gt_root'],
            content['gt_dir_name'],
            content['gt_format'],
            content['seq_names'],
            content['dataset'],
            content['date_included'],
            content['output_dir']
        )


class Loc3DCamConfig:
    """ Data class that specifies the camera 3D localization evaluation settings. """

    def __init__(self,
                 seq_names: list,
                 res_root: str,
                 res_dir_name: str,
                 res_format: str,
                 min_dist_thres: float,
                 gt_root: str = None,
                 gt_dir_name: str = None,
                 gt_format: str = None,
                 date_included: bool = True):
        self.seq_names = seq_names
        self.res_root = res_root
        self.res_dir_name = res_dir_name
        self.res_format = res_format
        self.min_dist_thres = min_dist_thres
        self.gt_root = gt_root
        self.gt_dir_name = gt_dir_name
        self.gt_format = gt_format
        self.date_included = date_included

    def serialize(self) -> dict:
        if self.gt_root is not None:
            return {
                "seq_names": self.seq_names,
                "res_root": self.res_root,
                "res_dir_name": self.res_dir_name,
                "res_format": self.res_format,
                "min_dist_thres": self.min_dist_thres,
                "gt_root": self.gt_root,
                "gt_dir_name": self.gt_dir_name,
                "gt_format": self.gt_format,
                "date_included": self.date_included
            }
        else:
            return {
                "seq_names": self.seq_names,
                "res_root": self.res_root,
                "res_dir_name": self.res_dir_name,
                "res_format": self.res_format,
                "min_dist_thres": self.min_dist_thres,
                "date_included": self.date_included
            }

    @classmethod
    def initialize(cls, content: dict):
        if 'gt_root' in content:
            return cls(
                content['seq_names'],
                content['res_root'],
                content['res_dir_name'],
                content['res_format'],
                content['min_dist_thres'],
                content['gt_root'],
                content['gt_dir_name'],
                content['gt_format'],
                content['date_included']
            )
        else:
            return cls(
                content['seq_names'],
                content['res_root'],
                content['res_dir_name'],
                content['res_format'],
                content['min_dist_thres'],
                content['date_included']
            )

def confmap2ra(radar_configs, name, radordeg='rad'):
    """
    Map confidence map to range(m) and angle(deg): not uniformed angle
    :param radar_configs: radar configurations
    :param name: 'range' for range mapping, 'angle' for angle mapping
    :param radordeg: choose from radius or degree for angle grid
    :return: mapping grids
    """
    # TODO: add more args for different network settings
    Fs = radar_configs['sample_freq']
    sweepSlope = radar_configs['sweep_slope']
    num_crop = radar_configs['crop_num']
    fft_Rang = radar_configs['ramap_rsize'] + 2 * num_crop
    fft_Ang = radar_configs['ramap_asize']
    c = scipy.constants.speed_of_light

    if name == 'range':
        freq_res = Fs / fft_Rang
        freq_grid = np.arange(fft_Rang) * freq_res
        rng_grid = freq_grid * c / sweepSlope / 2
        rng_grid = rng_grid[num_crop:fft_Rang - num_crop]
        return rng_grid

    if name == 'angle':
        # for [-90, 90], w will be [-1, 1]
        w = np.linspace(math.sin(math.radians(radar_configs['ra_min'])),
                        math.sin(math.radians(radar_configs['ra_max'])),
                        radar_configs['ramap_asize'])
        if radordeg == 'deg':
            agl_grid = np.degrees(np.arcsin(w))  # rad to deg
        elif radordeg == 'rad':
            agl_grid = np.arcsin(w)
        else:
            raise TypeError
        return agl_grid


def labelmap2ra(radar_configs, name, radordeg='rad'):
    """
    Map label map to range(m) and angle(deg): uniformed angle
    :param name: 'range' for range mapping, 'angle' for angle mapping
    :return: mapping grids
    """
    # TODO: add more args for different network settings
    Fs = radar_configs['sample_freq']
    sweepSlope = radar_configs['sweep_slope']
    num_crop = radar_configs['crop_num']
    fft_Rang = radar_configs['ramap_rsize_label'] + 2 * num_crop
    fft_Ang = radar_configs['ramap_asize_label']
    c = scipy.constants.speed_of_light

    if name == 'range':
        freq_res = Fs / fft_Rang
        freq_grid = np.arange(fft_Rang) * freq_res
        rng_grid = freq_grid * c / sweepSlope / 2
        rng_grid = rng_grid[num_crop:fft_Rang - num_crop]
        rng_grid = np.flip(rng_grid)
        return rng_grid

    if name == 'angle':
        if radordeg == 'rad':
            agl_grid = np.linspace(math.radians(radar_configs['ra_min_label']),
                                   math.radians(radar_configs['ra_max_label']),
                                   radar_configs['ramap_asize_label'])  # deg to rad
        elif radordeg == 'deg':
            agl_grid = np.linspace(radar_configs['ra_min_label'], radar_configs['ra_max_label'],
                                   radar_configs['ramap_asize_label'])  # keep deg
        else:
            raise TypeError
        return agl_grid
    

if __name__ == '__main__':
    # test()
    print("okk")

