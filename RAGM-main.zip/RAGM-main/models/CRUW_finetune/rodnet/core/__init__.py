from .object_class import get_class_id, get_class_name
