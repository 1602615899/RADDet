import math

# 从真实标签文件中读取目标检测信息
def read_gt_txt(txt_path, n_frame, dataset):
    n_class = dataset.object_cfg.n_class
    classes = dataset.object_cfg.classes
    
    # 读取文本文件中的数据
    with open(txt_path, 'r') as f:
        data = f.readlines()
        
    # 初始化目标检测结果列表
    dets = [None] * n_frame
    
    # 遍历文件中的每一行数据
    for line in data:
        frame_id, r, a, class_name = line.rstrip().split()
        frame_id = int(frame_id)
        r = float(r)
        a = float(a)
        class_id = classes.index(class_name)
        
        # 创建包含目标信息的字典
        obj_dict = dict(
            frame_id=frame_id,
            range=r,
            angle=a,
            class_name=class_name,
            class_id=class_id
        )
        
        # 将目标信息添加到目标检测结果列表的适当帧中
        if dets[frame_id] is None:
            dets[frame_id] = [obj_dict]
        else:
            dets[frame_id].append(obj_dict)

    # 初始化真实标签字典，用于存储每帧每类别的目标信息
    gts = {(i, j): [] for i in range(n_frame) for j in range(n_class)}
    id = 1
    
    # 遍历每帧的目标信息
    for frameid, obj_info in enumerate(dets):
        # 跳过空帧
        if obj_info is None:
            continue
        for obj_dict in obj_info:
            rng = obj_dict['range']
            agl = obj_dict['angle']
            class_id = obj_dict['class_id']
            
            # 过滤掉不符合条件的目标
            if rng > 25 or rng < 1:
                continue
            if agl > math.radians(60) or agl < math.radians(-60):
                continue
            
            # 创建包含目标信息的字典，包括ID和分数
            obj_dict_gt = obj_dict.copy()
            obj_dict_gt['id'] = id
            obj_dict_gt['score'] = 1.0
            
            # 将真实标签信息添加到真实标签字典中
            gts[frameid, class_id].append(obj_dict_gt)
            id += 1

    return gts

# 从提交结果文件中读取目标检测信息
def read_sub_txt(txt_path, n_frame, dataset):
    n_class = dataset.object_cfg.n_class
    classes = dataset.object_cfg.classes
    
    # 读取文本文件中的数据
    with open(txt_path, 'r') as f:
        data = f.readlines()
        
    # 初始化目标检测结果列表
    dets = [None] * n_frame
    
    # 遍历文件中的每一行数据
    for line in data:
        frame_id, r, a, class_name, score  = line.rstrip().split()
        frame_id = int(frame_id)
        r = float(r)
        a = float(a)
        class_id = classes.index(class_name)
        score = float(score)
        
        # 限制分数范围在[0, 1]
        if score >= 1:
            score = 1
        
        # 创建包含目标信息的字典
        obj_dict = dict(
            frame_id=frame_id,
            range=r,
            angle=a,
            class_name=class_name,
            class_id=class_id,
            score=score
        )
        
        # 将目标信息添加到目标检测结果列表的适当帧中
        if dets[frame_id] is None:
            dets[frame_id] = [obj_dict]
        else:
            dets[frame_id].append(obj_dict)

    # 初始化目标检测字典，用于存储每帧每类别的目标信息
    dts = {(i, j): [] for i in range(n_frame) for j in range(n_class)}
    id = 1
    
    # 遍历每帧的目标信息
    for frameid, obj_info in enumerate(dets):
        # 跳过空帧
        if obj_info is None:
            continue
        for obj_dict in obj_info:
            rng = obj_dict['range']
            agl = obj_dict['angle']
            class_id = obj_dict['class_id']
            
            # 过滤掉不符合条件的目标
            if rng > 25 or rng < 1:
                continue
            if agl > math.radians(60) or agl < math.radians(-60):
                continue
            
            # 创建包含目标信息的字典，包括ID
            obj_dict_gt = obj_dict.copy()
            obj_dict_gt['id'] = id
            
            # 将目标检测信息添加到目标检测字典中
            dts[frameid, class_id].append(obj_dict_gt)
            id += 1

    return dts
