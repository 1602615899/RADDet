import os
import numpy as np

from .load_txt import read_gt_txt, read_sub_txt
from .rod_eval_utils import compute_ols_dts_gts, evaluate_img, accumulate, summarize

# 定义一些评估所需的阈值
olsThrs = np.around(np.linspace(0.5, 0.9, int(np.round((0.9 - 0.5) / 0.05) + 1), endpoint=True), decimals=2)
recThrs = np.around(np.linspace(0.0, 1.0, int(np.round((1.0 - 0.0) / 0.01) + 1), endpoint=True), decimals=2)

# 定义函数，用于评估目标检测模型在Rod2021数据集上的性能
def evaluate_rod2021(submit_dir, truth_dir, dataset, output_txt=None):
    # 获取提交结果文件和真实标签文件的名称列表
    sub_names = sorted(os.listdir(submit_dir))
    gt_names = sorted(os.listdir(truth_dir))
    
    # 检查提交结果文件和真实标签文件是否一一对应
    assert len(sub_names) == len(gt_names), "missing submission files!"
    for sub_name, gt_name in zip(sub_names, gt_names):
        if sub_name != gt_name:
            raise AssertionError("wrong submission file names!")

    # 初始化评估结果和其他变量
    evalImgs_all = []
    n_frames_all = 0
    ols_list = []

    # 针对每个序列进行评估
    for seqid, (sub_name, gt_name) in enumerate(zip(sub_names, gt_names)):
        # 构建真实标签和提交结果的完整路径
        gt_path = os.path.join(truth_dir, gt_name)
        sub_path = os.path.join(submit_dir, sub_name)
        
        # 获取数据路径和帧数
        data_path = os.path.join(dataset.data_root, 'sequences', 'test', gt_names[seqid][:-4])
        n_frame = len(os.listdir(os.path.join(data_path, dataset.sensor_cfg.camera_cfg['image_folder'])))

        # 从真实标签和提交结果文件中读取目标检测信息
        gt_dets = read_gt_txt(gt_path, n_frame, dataset)
        sub_dets = read_sub_txt(sub_path, n_frame, dataset)

        # 计算重叠度分数（Overlap Scores）
        olss_all = {(imgId, catId): compute_ols_dts_gts(gt_dets, sub_dets, imgId, catId, dataset) \
                    for imgId in range(n_frame)
                    for catId in range(3)}

        # 将重叠度分数存储在列表中
        for olss in list(olss_all.values()):
            if len(olss) > 0:
                olss_max_gt = np.amax(olss, axis=0)
                cur_olss = list(np.ravel(np.squeeze(olss_max_gt)))
                ols_list.extend(cur_olss)

        # 评估每一帧的检测结果
        evalImgs = [evaluate_img(gt_dets, sub_dets, imgId, catId, olss_all, olsThrs, recThrs, dataset)
                    for imgId in range(n_frame)
                    for catId in range(3)]

        # 更新总帧数和评估结果列表
        n_frames_all += n_frame
        evalImgs_all.extend(evalImgs)

    # 计算各类别的平均精确度（AP）和平均召回率（AR）
    class_AP = np.zeros(4)
    class_AR = np.zeros(4)

    for class_id in range(4):
        eval = accumulate(evalImgs_all, n_frames_all, olsThrs, recThrs, dataset, log=False, class_id=class_id)
        stats = summarize(eval, olsThrs, recThrs, dataset, gl=False)
        class_AP[class_id] = stats[0] * 100
        class_AR[class_id] = stats[1] * 100

    ap_result = "AP_total: %.4f | AP_pedestrian: %.4f | AP_cyclist: %.4f | AP_car: %.4f" % \
                (class_AP[3], class_AP[0], class_AP[1], class_AP[2])
    ar_result = "AR_total: %.4f | AR_pedestrian: %.4f | AR_cyclist: %.4f | AR_car: %.4f" % \
                (class_AR[3], class_AR[0], class_AR[1], class_AR[2])

    print(ap_result)
    print(ar_result)

    if output_txt:
        with open(output_txt, 'w') as f:
            f.write(ap_result + '\n')
            f.write(ar_result + '\n')

    return class_AP, class_AR
    # # 打印每个类别和总体的平均精确度和平均召回率
    # print("AP_total: %.4f | AP_pedestrian: %.4f | AP_cyclist: %.4f | AP_car: %.4f" % (class_AP[3], class_AP[0], class_AP[1], class_AP[2]))
    # print("AR_total: %.4f | AR_pedestrian: %.4f | AR_cyclist: %.4f | AR_car: %.4f" % (class_AR[3], class_AR[0], class_AR[1], class_AR[2]))
