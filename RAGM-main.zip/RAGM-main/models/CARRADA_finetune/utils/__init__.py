import pathlib

MVRSS_HOME = pathlib.Path(__file__).resolve().parents[1]
